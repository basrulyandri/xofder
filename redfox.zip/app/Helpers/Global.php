<?php
function toRp($angka)
{
 	$jadi = "Rp. " . number_format($angka,0,',','.');
	return $jadi;
}

function getSetting($key)
{
	return \App\Setting::whereSettingKey($key)->first()->setting_value;
}

function stockFrom($stock){
	if($stock->stock_from == 'supplier'){
		return $stock->supplier->name;
	}
}

