<?php

return [
	'APP_NAME' => 'REDFOX STORE',
	'KASIR_PREFIX_URL' => 'kasir',	
];